// src/setupTests.ts

// `toBeInTheDocument`와 같은 유용한 DOM 관련 테스트 함수를 사용하기 위해 import 합니다.
import '@testing-library/jest-dom';