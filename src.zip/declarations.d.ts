declare global {
  interface Window {
    Kakao: any;
  }
}

// 이 파일을 모듈로 인식시키지 않도록 export {}를 사용합니다.
export {};