// functions/src/callable/points.ts

//import { onCall, HttpsError } from "firebase-functions/v2/https";
//import { dbAdmin as db, allowedOrigins } from "../firebase/admin.js";
//import { Timestamp, FieldValue } from "firebase-admin/firestore";
//import type { Product, UserDocument, PointLog } from "../types.js";
//import * as logger from "firebase-functions/logger";

